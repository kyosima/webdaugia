<iframe width="100%" height="500"src="{{$detail->video}}">
</iframe>