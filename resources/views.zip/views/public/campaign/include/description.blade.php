<p>{!! $product->desc_long!!}</p>
