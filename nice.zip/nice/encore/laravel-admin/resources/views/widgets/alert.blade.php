<div {!! $attributes !!} >
    <button type="button" class="close" data-dismiss="alert">×</button>
    <h4><i class="icon fa fa-{{ $icon }}"></i> {{ $title }}</h4>
    {!! $content !!}
</div>