<div class="form-group">
    <label>{{ $label }}</label>
    <input style="width: 100%" {!! $attributes !!} />
    @include('admin::actions.form.help-block')
</div>