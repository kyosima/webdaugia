<?php

namespace App\Admin\Extensions\Form;

use Encore\Admin\Form\Field;

class InputProductOrder extends Field
{

    protected $view = 'input-product-order';

    public function render()
    {
        return parent::render();
    }
}