<?php

if (!function_exists('helper')) {
    function helper()
    {
        return 'Đây là Helper tùy chỉnh';
    }
}